import asyncio
import datetime
import json
import threading
import time
import os.path
from copy import deepcopy

import discord
from discord.ext import (
    tasks as discord_tasks,
    commands as discord_commands
)

from endstone import ColorFormat, Player, GameMode, Logger
from endstone.event import PlayerChatEvent
from endstone.command import Command, CommandSender
from endstone.event import *
from endstone.plugin import Plugin



def parse_duration(duration_str: str) -> int|None:
    if duration_str.casefold() in {'inf', 'infinite', 'infinity', 'forever', 'perma', 'permanent'}:
        return None

    if len(duration_str) < 2:
        raise ValueError

    try:
        value = int(duration_str[:-1])
    except ValueError:
        raise ValueError

    unit = duration_str[-1]
    if unit == 's':
        factor = 1
    elif unit == 'm':
        factor = 60
    elif unit == 'h':
        factor = 60 * 60
    elif unit == 'D':
        factor = 60 * 60 * 24
    elif unit == 'M':
        factor = 60 * 60 * 24 * 30
    elif unit == 'Y':
        factor = 60 * 60 * 24 * 30 * 12
    else:
        raise ValueError
    duration = value * factor

    return duration


def timestamp_to_string(timestamp: float) -> str:
    return datetime.datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M")


def generate_ban_message(expiration_timestamp: int|None, reason: str|None) -> str:
    if expiration_timestamp is None:
        message = "§cYou have been §4permanently §cbanned from this server!"
    else:
        expiration_str = timestamp_to_string(expiration_timestamp) + " §7(GMT+01)"
        message = f"§cYou have been banned from this server!\n§gExpiration§f: {expiration_str}"

    if reason is not None:
        message += f"\n§gReason§f: {reason}"

    message += "\n\n§3[§bYou can appeal in the Discord Server: §dbit.ly/tomatigga§3]"
    return message



class MyDiscordClient(discord.Client):
    BAN_CHANNEL_ID = 1337553418050338926
    BANLIST_CHANNEL_ID = 1337550184602796113
    BANLIST_MESSAGE_ID = 1337552599154430023

    def __init__(self, *args, **kwargs):
        try:
            super().__init__(*args, **kwargs)
            self.banlist: list[dict] = []
            self.__banlist: list[dict] = []
            self.message_queue: list[str] = []
        except Exception as e:
            print(type(e).__name__, e)


    async def __get_banlist(self) -> list[dict]:
        try:
            channel = self.get_channel(self.BANLIST_CHANNEL_ID)
            message = await channel.fetch_message(self.BANLIST_MESSAGE_ID)
            file_content = await message.attachments[0].read()
            return json.loads(file_content)
        except Exception as e:
            print(type(e).__name__, e)


    async def __update_banlist(self) -> None:
        try:
            channel = self.get_channel(self.BANLIST_CHANNEL_ID)
            text = json.dumps(self.banlist)
            message = await channel.fetch_message(self.BANLIST_MESSAGE_ID)

            file_path = os.path.join(os.path.dirname(__file__), "__tempdc.txt")
            with open(file_path, 'w') as file:
                file.write(text)

            file = discord.File(file_path)
            await message.edit(attachments=[file])

            print("[Discord] Updated ban list successfully!")
        except Exception as e:
            print(type(e).__name__, e)


    async def on_ready(self):
        try:
            print(f'[Discord] Logged on as {self.user}!')
            now = time.time()

            self.banlist = await self.__get_banlist()
            self.banlist = [ban for ban in self.banlist if ban.get('expiration') is not None and now > ban['expiration']]
            self.__banlist = deepcopy(self.banlist)
            await self.__update_banlist()

            ban_channel = self.get_channel(self.BAN_CHANNEL_ID)
            await self.timer.start(ban_channel)

        except Exception as e:
            print(type(e).__name__, e)


    @discord_tasks.loop(seconds=2)
    async def timer(self, channel):
        try:
            # -- Update ban messages
            for i, message_str in enumerate(self.message_queue):
                await channel.send(message_str)
                print("[Discord] Sent ban message!")
                del self.message_queue[i]

            # -- Update banlist
            if self.__banlist != self.banlist:
                # self.banlist was updated from outside; update the discord message
                await self.__update_banlist()
                print("[Discord] Updated banlist message!")
                self.__banlist = deepcopy(self.banlist)
        except Exception as e:
            print(type(e).__name__, e)


def run_discord_bot(logger: Logger) -> MyDiscordClient|None:
    intents = discord.Intents.default()
    # intents.message_content = True
    intents.typing = True

    client = MyDiscordClient(intents=intents)

    try:
        with open(os.path.join(os.path.dirname(__file__), "discord_string.txt"), 'r') as file:
            discord_auth_string = file.read().strip(" \n\r\t")
    except Exception as exc:
        logger.error(f"Could not extract discord auth string because: {exc.__name__}: {exc}")
        return None

    threading.Thread(target=client.run, args=(discord_auth_string,), daemon=True).start()
    return client


class BioManagementPlugin(Plugin):
    prefix = "BioManage"
    api_version = "0.5"
    load = "POSTWORLD"

    commands = {
        "gm": {
            "description": "Change your gamemode.",
            "usages": ["/gm <gameMode: message>"],
            "permissions": ["bio_management.command.gm"],
        },
        "gm0": {
            "description": "Change your gamemode to Survival.",
            "usages": ["/gm0"],
            "aliases": ["gms"],
            "permissions": ["bio_management.command.gm"],
        },
        "gm1": {
            "description": "Change your gamemode to Creative.",
            "usages": ["/gm1"],
            "aliases": ["gmc"],
            "permissions": ["bio_management.command.gm"],
        },
        "gm2": {
            "description": "Change your gamemode to Adventure.",
            "usages": ["/gm2"],
            "aliases": ["gma"],
            "permissions": ["bio_management.command.gm"],
        },
        "gm3": {
            "description": "Change your gamemode to Spectator.",
            "usages": ["/gm3"],
            "aliases": ["gmp"],
            "permissions": ["bio_management.command.gm"],
        },
        "bann": {
            "description": "Ban a player from the server.",
            "usages": ["/bann <player: target> [duration: message] [reason: message]"],
            "permissions": ["bio_management.server_admin"],
        },

    }

    permissions = {
        "bio_management.command": {
            "description": "Allow users to use all commands provided by this plugin.",
            "default": True,
            "children": {}
        },
        "bio_management.server_admin": {
            "description": "Allow users to use the /bann and /unbann commands.",
            "default": 'op',  # idfk how the permission system works
        },
        "bio_management.command.gm": {
            "description": "Allow users to use the /gm, /gmc, /gms commands.",
            "default": 'op',
        },
    }

    def send_admin(self, message: str) -> None:
        self.logger.info(message)

        for player in self.server.online_players:
            if player.is_op:
                player.send_message(message)


    def on_load(self) -> None:
        self.logger.info("on_load is called!")
        global discord_bot
        discord_bot = run_discord_bot(self.logger)

        if discord_bot is None:
            self.logger.warning("Could not load Discord bot!")
        else:
            self.logger.info("Loaded Discord Bot Successfully!")

    def on_enable(self) -> None:
        self.logger.info("on_enable is called!")
        self.register_events(self)

    def on_disable(self) -> None:
        self.logger.info("on_disable is called!")


    def ban_player(self, player: Player, expiration_timestamp: float = None, reason:str = None):
        expiration_timestamp = int(expiration_timestamp)
        kick_message = generate_ban_message(expiration_timestamp, reason)
        player.kick(kick_message)

        # keep track of bans using discord bot
        if discord_bot is None:
            self.logger.error(f"§cCould not ban player \"{player.name}\" because the Discord Bot is not initialized!")
            return

        expiration_str = "**Never**" if expiration_timestamp is None else f"<t:{int(expiration_timestamp)}:F>"
        reason_str = "Unspecified" if reason is None else f"`{reason}`"

        discord_message = \
            f"Gamertag: `{player.name}`\n" + \
            f"Expiration: {expiration_str}\n" + \
            f"Reason: `{reason_str}`\n" + \
            f"\n" + \
            f"UUID: `{player.unique_id}`\n" + \
            f"XUID: `{player.xuid}`\n" + \
            f"IP: `{player.address.hostname}`\n" + \
            f"Device ID: `{player.device_id}`\n" + \
            f"Extra Information: ```Operating System: {player.device_os}\nGame Version: {player.game_version}\nGame Language: {player.locale}```"

        discord_bot.message_queue.append(discord_message)

        discord_bot.banlist.append({
            'name': player.name,
            'expiration': expiration_timestamp,
            'xuid': player.xuid,
            'ip': player.address.hostname,
            'device_id': player.device_id
        })


    @event_handler
    def on_server_load(self, event: ServerLoadEvent):
        self.logger.info(ColorFormat.GREEN + f"{event.event_name} is passed to on_server_load")

    # @event_handler
    # def on_player_chat(self, event: PlayerChatEvent):
    #     self.logger.info(event.message)

    @event_handler
    def on_player_command(self, event: PlayerCommandEvent):
        if "/me" in event.command:
            if any(i in event.command for i in {"@e", "@a", "@p", "@r", "@s"}) or len(event.command) >= 100:
                # ban player for spam/crasher
                self.ban_player(event.player, None, "Crasher")


    @event_handler
    def on_player_login(self, event: PlayerLoginEvent):
        now = time.time()

        # check if banned
        for ban in discord_bot.banlist:
            reason = ban.get('reason')
            expiration = ban.get('expiration')
            if expiration is not None and now >= expiration:
                # ban no longer valid
                return

            if (
                ban['name'] == event.player.name or
                ban['xuid'] == event.player.xuid or
                ban['ip'] == event.player.address.hostname or
                ban['device_id'] == event.player.device_id
            ):
                event.cancelled = True
                event.kick_message = generate_ban_message(expiration, reason)



    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if len(command.name) == 3 and command.name.startswith("gm"):
            return self.command_gm(sender, command.name[2])

        elif command.name == 'gm':
            if len(args) != 1:
                sender.send_error_message("Usage: /gm <gamemode: GameMode>")
                return False

            return self.command_gm(sender, args[0])

        elif command.name == 'bann':
            if len(args) == 1:
                return self.command_ban(sender, args[0])
            elif len(args) == 2:
                return self.command_ban(sender, args[0], args[1])
            elif len(args) == 3:
                return self.command_ban(sender, args[0], args[1], args[2])
            else:
                sender.send_error_message("Usage: /ban <player: Player> [duration: TimeDuration] [reason: Text]")
                return False

        elif command.name == 'unbann':
            if len(args) != 1:
                sender.send_error_message("Usage: /unban <player: Player>")
                return False

            return self.command_unban(sender, args[0])


        return True


    def command_gm(self, sender: CommandSender, gamemode_str: str) -> bool:
        if not isinstance(sender, Player):
            sender.send_error_message("You must be a player to execute this command.")
            return False

        gamemode_str = gamemode_str.strip().casefold()

        if gamemode_str in {'0', 's', 'sur', 'surv', 'survival', 'überleben'}:
            gamemode = GameMode.SURVIVAL
        elif gamemode_str in {'1', 'c', 'cr', 'crea', 'creativ', 'creative', 'kreativ'}:
            gamemode = GameMode.CREATIVE
        elif gamemode_str in {'2', 'a', 'ad', 'adv', 'adven', 'adventure', 'abenteuer'}:
            gamemode = GameMode.ADVENTURE
        elif gamemode_str in {'3', '6', 'p', 'sp', 'spe', 'spec', 'spect', 'spectator', 'zuschauer'}:
            gamemode = GameMode.SPECTATOR
        else:
            sender.send_error_message("§cInvalid Gamemode!")
            return False

        sender.game_mode = gamemode
        sender.send_message(f"§bChanged gamemode to §3{gamemode.name.capitalize()}§b.")
        return True


    def command_ban(self, sender: CommandSender, player_str: str, duration_str: str = None, reason: str = None) -> bool:
        player = self.server.get_player(player_str)
        if player is None:
            sender.send_error_message("Player is offline! Use vanilla ban command to ban by name.")
            return False

        expiration_timestamp = None
        if duration_str is not None:
            try:
                duration_seconds = parse_duration(duration_str)
            except ValueError:
                sender.send_error_message("Invalid duration! Should look like \"162h\", \"4Y\" or \"inf\".")
                return False

            if duration_seconds is not None:
                expiration_timestamp = time.time() + duration_seconds

        self.ban_player(player, expiration_timestamp, reason)

        sender.send_message(f"§aPlayer \"{player.name}\" banned successfully!")
        return True


    def command_unban(self, sender: CommandSender, player_str: str):
        for i, ban in enumerate(discord_bot.banlist):
            if ban['name'].casefold() != player_str.casefold():
                continue

            del discord_bot.banlist[i]
            sender.send_message(f"Player \"{ban['name']}\" has been unbanned successfully!")
            return True

        sender.send_error_message(f"Could not find banned player \"{player_str}\"!")
        return False


# Globals
discord_bot: MyDiscordClient = None