import csv
import os


def ip_raw_to_str(ip_raw: int) -> str:
    ip_parts: list[str] = []

    for i in range(4):
        ip_parts.append(str(ip_raw % 256))
        ip_raw //= 256

    return ".".join(ip_parts[::-1])


def ip_str_to_raw(ip_str: str) -> int:
    n = 0

    for i, ip_part in enumerate(ip_str.split(".")):
        n += 256**i * int(ip_part)

    return n


def parse_line(line: str) -> list[str]:
    elements: list[str] = []
    i = 0
    start = 0
    len_line = len(line)
    currently_in_string = False

    while i < len_line:
        if line[i] == '"':
            currently_in_string = not currently_in_string
            if currently_in_string:
                start = i + 1
            else:
                elements.append(line[start : i])
        i += 1

    return elements



def get_data_by_ip(ip_address: str):
    ip_raw = ip_str_to_raw(ip_address)
    for ip_from, ip_to, data in ip_regions:
        if not (ip_from <= ip_raw <= ip_to): continue
        return data


def data_get_coordinates(data: tuple) -> tuple[float, float]:
    country_code, country_name, region_name, city_name, latitude, longitude = data
    return float(latitude), float(longitude)

def data_get_country_name(data: tuple) -> str:
    country_code, country_name, region_name, city_name, latitude, longitude = data
    return country_name

def data_get_region_name(data: tuple) -> str:
    country_code, country_name, region_name, city_name, latitude, longitude = data
    return region_name

def data_get_city_name(data: tuple) -> str:
    country_code, country_name, region_name, city_name, latitude, longitude = data
    return city_name



ip_regions: tuple[int, int, tuple[str]] = []

try:
    with open(os.path.join(os.path.dirname(__file__), "IP2LOCATION-LITE-DB5.csv"), 'r') as file:
        __lines = file.read().strip(" \n\r\t").split("\n")
except Exception as exc:
    raise Exception(f"Could not extract CSV IP locations because: {exc.__name__}: {exc}")


for i, line in enumerate(__lines):
    __ip_from_raw, __ip_to_raw, __country_code, __country_name, __region_name, __city_name, __latitude, __longitude = parse_line(line)
    if __country_name == '-': continue

    # __ip_from = ip_raw_to_str(int(__ip_from_raw))
    # __ip_to = ip_raw_to_str(int(__ip_to_raw))
    # print(f"{__ip_from} - {__ip_to} | {__latitude} {__longitude} | {__city_name} in {__region_name}, {__country_name}")
    # break

    ip_regions.append((__ip_from_raw, __ip_to_raw, (__country_code, __country_name, __region_name, __city_name, __latitude, __longitude)))



try:
    with open(os.path.join(os.path.dirname(__file__), "ip_locations.py"), 'w') as file:
        file.write(str(ip_regions))
except Exception as exc:
    raise Exception(f"Could not write converted CSV IP locations because: {exc.__name__}: {exc}")
