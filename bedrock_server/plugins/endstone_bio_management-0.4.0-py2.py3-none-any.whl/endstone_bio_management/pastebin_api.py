import requests
import os

try:
    with open(os.path.join(os.path.dirname(__file__), "pastebin_string.txt"), 'r') as file:
        pastebin_auth_string = file.read().strip(" \n\r\t")
except Exception as exc:
    print(f"Could not extract discord auth string because: {exc.__name__}: {exc}")
    exit(1)


# https://pastebin.com/doc_api?ref=free-for-dev.com
def update_post(content: str):
    url = "https://pastebin.com/api/api_post.php"
    params = {
        "api_option": "paste",
        "api_user_key": "",
        "api_paste_private": "1",               # 0: public, 1: unlisted, (2: private)
        "api_paste_name": "mc_bio_banlist",
        "api_paste_expire_date": "N",           # N: never
        "api_paste_format": "php",
        "api_dev_key": pastebin_auth_string,
        "api_paste_code": content,
    }

    r = requests.post(url, params=params)

    print(pastebin_auth_string, r, r.text)

    # 'api_option=paste&api_user_key='.$api_user_key.
    # '&api_paste_private='.$api_paste_private.
    # '&api_paste_name='.$api_paste_name.
    # '&api_paste_expire_date='.$api_paste_expire_date.
    # '&api_paste_format='.$api_paste_format.
    # '&api_dev_key='.$api_dev_key.
    # '&api_paste_code='.$api_paste_code.
    # '');


update_post("txt sample!!! contentt")