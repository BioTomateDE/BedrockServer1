import os
import threading

import discord
from discord.ext import commands, tasks
import datetime

try:
    with open(os.path.join(os.path.dirname(__file__), "discord_string.txt"), 'r') as file:
        discord_auth_string = file.read().strip(" \n\r\t")
except Exception as exc:
    print(f"Could not extract discord auth string because: {exc.__name__}: {exc}")
    exit(1)


# GLOBAL
discord_bot_queue: list[str] = []
# --


class MyDiscordClient(commands.Bot):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.msg_sent = False

    async def on_ready(self):
        print("ready")
        channel = self.get_channel(1337550184602796113)
        print("channel:", channel.name)
        # await channel.send("sssdfg")
        await self.timer.start(channel)

    @tasks.loop(seconds=1)
    async def timer(self, channel: discord.TextChannel):
        global discord_bot_queue
        if not discord_bot_queue: return

        file = discord.File(os.path.join(os.path.dirname(__file__), "__tempdc.txt"))

        for i, message in enumerate(discord_bot_queue):
            await channel.send(message, file=file)
            del discord_bot_queue[i]



intents = discord.Intents.default()
intents.typing = True
bot = MyDiscordClient(command_prefix='?', intents=intents)

# bot.run(discord_auth_string)
threading.Thread(target=bot.run, args=(discord_auth_string,), daemon=True).start()
print("Started.")

while True:
    string = input("> ")
    discord_bot_queue.append(string)
